./output/main.o: ../Application/main.c \
  ../GD32E23x_Firmware_Library/CMSIS/GD/GD32E23x/Include\gd32e23x.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.3.0/CMSIS/Include\core_cm23.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.3.0/CMSIS/Include/cmsis_version.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.3.0/CMSIS/Include/cmsis_compiler.h \
  C:/Keil_v5/ARM/PACK/ARM/CMSIS/5.3.0/CMSIS/Include/cmsis_armclang.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  ../GD32E23x_Firmware_Library/CMSIS/GD/GD32E23x/Include/system_gd32e23x.h \
  ../Application\gd32e23x_libopt.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_adc.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_crc.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_dbg.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_dma.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_exti.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_fmc.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_gpio.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_syscfg.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_i2c.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_fwdgt.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_pmu.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_rcu.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_rtc.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_spi.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_timer.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_usart.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_wwdgt.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_misc.h \
  ../GD32E23x_Firmware_Library/GD32E23x_standard_peripheral/Include\gd32e23x_cmp.h \
  ../Application/systick.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h ../User\led.h \
  ../User\delay.h ../User\usart.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdlib.h
